package com.mycompany.taskclteh;

/**
 *
 * @author juans
 */
public class Main {

    public static void main(String[] args) {
//        maxDivisor maDivisor= new maxDivisor();
//        System.out.println("El maximo común divisor entre " + maDivisor.mcd());

//        Descender array = new Descender();
//        array.values();

        CashMachine atm = new CashMachine();
        atm.machine();

    }
}
