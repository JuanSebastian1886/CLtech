package com.mycompany.taskclteh;

/**
 *
 * @author juans
 */
public class maxDivisor {

    public double mcd() {
        double numerador, denominador;
        numerador = 72;
        denominador = 16;
        double result=0;
        double module=0;
        do{            
        result =denominador; //nuevo numerador
        module= numerador % denominador; //nuevo denominador
        numerador = result;
        denominador=module;
        }while (module != 0);

        return result;
    }
}

