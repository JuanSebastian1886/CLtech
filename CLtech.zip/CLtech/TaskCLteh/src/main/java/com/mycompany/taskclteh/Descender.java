package com.mycompany.taskclteh;

import java.util.Scanner;

public class Descender {

    public void values() {
        Scanner sc = new Scanner(System.in);

        int[] numbers = new int[5];

        for (int i = 0; i < numbers.length; i++) {
            System.out.println("Ingrese el numero " + (i + 1) + " : ");
            int number = sc.nextInt();
            numbers[i] = number;
        }
        int max = numbers[0];

        for (int x = 1; x < numbers.length; x++) {
            if (numbers[x] > max) {
                max = numbers[x];
            }
        }
        System.out.println("El mayor es: " + max);
        System.out.println("");

        int low = numbers[0];

        for (int x = 1; x < numbers.length; x++) {
            if (numbers[x] < low) {
                low = numbers[x];
            }
        }
        System.out.println("El menor es: " + low);
        System.out.println("");

        System.out.println("Numbers: ");
        for (int number : numbers) {
            System.out.print(number + "-");
        }
    }
}
