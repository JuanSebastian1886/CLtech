package com.mycompany.taskclteh;

import java.util.Scanner;

/**
 *
 * @author juans
 */
public class CashMachine {

    public void machine() {

        Scanner entry = new Scanner(System.in);
        int option = 0;
        double totalAccount = 2350000;
        int password=1234;

        do {
            /**
             * Impresión del menú
             */
            System.out.println("Seleccione una opción");
            System.out.println("1.Consulta de saldo");
            System.out.println("2.Retiro de dinero");
            System.out.println("3.Cambio de contraseña");
            System.out.println("4.Finalizar la operación en curso");

            option = entry.nextInt();
            if (option < 5) {

                switch (option) {

                    case 1:
                        System.out.println("Su saldo es: " + totalAccount);
                        break;
                    case 2:                        
                        System.out.println("Ingrese la cantidad a retirar en multiplos de 10.000");
                        double retire = entry.nextDouble();
                        if (retire <= totalAccount) {
                            totalAccount -= retire;
                            System.out.println("Su nuevo saldo es de: " + totalAccount);
                            break;
                        }else{
                            System.out.println("Fondos insuficientes");
                        }
                    case 3:
                        System.out.println("Ingrese su contraseña" );
                        int compare=entry.nextInt();
                        if(compare==password){                            
                            System.out.println("Ingrese su nueva contraseña:");
                            password = entry.nextInt();
                            System.out.println("Contraseña modificada con exito!");
                        }else{
                            System.out.println("Contraseña invalida");
                        }
                        break;
                    case 4:
                        System.out.println("Finalizando operación ...");
                        break;
                    default:
                        throw new AssertionError();
                }
                System.out.println("");
            } else {
                System.out.println("Escoja una opción válida");
            }
        } while (option != 4);
    }
}
/**
 *  }else{
            if(!ax.equals("")){            
                if(ax.equals(clave)){//si la clave digitada coincide con la clave
                    ax = JOptionPane.showInputDialog(null, "a. 5000 n b. 10.000 n c. 20.000 n d. 50.000n e. 100.000n f. Ingresar valor",
                            "CANTIDAD A RETIRAR", JOptionPane.INFORMATION_MESSAGE);
                    if(ax!=null){
                        if(!ax.equals("")){
                            switch(ax){
                                case "a":
                                    if((saldo-5000&gt;=10000)){//se verifica si al retirar queda con un saldo minimo de 10.000
                                        saldo-=5000;
                                    }                            
                                    break;
                                case "b":
                                   if((saldo-10000&gt;=10000)){//se verifica si al retirar queda con un saldo minimo de 10.000
                                        saldo-=10000;
                                    }
                                    break;
                                case "c":
                                   if((saldo-20000&gt;=10000)){//se verifica si al retirar queda con un saldo minimo de 10.000
                                        saldo-=20000;
                                    }
                                    break;
                                case "d":
                                    if((saldo-50000&gt;=10000)){//se verifica si al retirar queda con un saldo minimo de 10.000
                                        saldo-=50000;
                                    }
                                    break;
                                case "e":
                                    if((saldo-100000&gt;=10000)){//se verifica si al retirar queda con un saldo minimo de 10.000
                                        saldo-=100000;
                                    }
                                    break;
                                case "f":
                                    ax = JOptionPane.showInputDialog(null, "Digite el valor a retirar: ");
                                    if(!ax.equals("") &amp;&amp; auxi.isNum(ax) &amp;&amp; (Integer.parseInt(ax)&gt;0) &amp;&amp; (saldo-Integer.parseInt(ax)&gt;=10000) ){
                                        saldo-= Integer.parseInt(ax);
                                    }
                                    break;
                                default:
                                    JOptionPane.showMessageDialog(null, "Digite una opcion valida", "OPCION INCORRECTA", JOptionPane.ERROR_MESSAGE);
                                    break;
                            }             
                        } 
                    }
                }
                else{
                    JOptionPane.showMessageDialog(null, "La clave ingresada no coincide....");
                }
            }
        }              
    }
 */
